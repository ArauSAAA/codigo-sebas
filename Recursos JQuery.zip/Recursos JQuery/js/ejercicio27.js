$(function(){
    $("#draggable").draggable()
    //widget
    // JQuery
    $("#acordion").accordion()

    $("#tabs").tabs()

    $("#abrirDialogo").on("click",function(){
        $("#dialogo").dialog();
    })
})