$(function(){
    $(".div1").text("<strong>Texto del div1</strong>");
    $("#div2").html("<strong>Texto del div2</strong>")
    // window.alert(`Texto div1: ${$(".div1").text()}`)
    // window.alert(`Texto div2: ${$("#div2").html()}`)
    //Manejo de eventos (metodo on())
    $(".div1").on("click", function(){
      $("#div2").css(prop)

    });
    $("#div3").on("click", function(){
        $("#div2").css("color", "black")
      $("#div2").css("background-color", "white")
      $("#div2").css("font-family", "calibri")
      $("#div2").css("text-align", "left")

    })

    const prop = {
        "color": "red",
        "background-color": "pink",
        "font-family" : "calibri",
        "text-align" : "center"

    }

    //manejo de atributos
    const imagen = $("#imgOff")
  

    imagen.on("mouseover", function(){
        imagen.attr("src","img/lamp_on.jpg")
    })
    imagen.on("mouseout", function(){
        imagen.attr("src","img/lamp_off.jpg")
    })

    //Ejecucion de efectos

    $("#aplicarEfecto").on("click", function(){
        $("#efectos").hide(2000)
    })

    $("#quitarEfecto").on("click", function(){
        $("#efectos").show(2000)
    })

    setInterval(mostrarFecha, 1000)
    mostrarFecha()

});

function mostrarFecha(){
    const today = new Date()
    $("#fecha").html(today.toLocaleString("es-ES"))
}